<div class="site-section ftco-subscribe-1 site-blocks-cover pb-4"
    style="background-image: url('assets/images/course_6.jpg')">
    <div class="container">
        <div class="row align-items-end">
            <div class="col-lg-7">
                <h2 class="mb-0">Daftar Mitra Industri</h2>
            </div>
        </div>
    </div>
</div>

<br><br>
<center>
<div class="card mb-3" style="max-width: 840px;">
    <div class="row no-gutters">
        <div class="col-md-4">
            <img src="assets/images/person_1.jpg" class="card-img" alt="...">
        </div>
        <div class="col-md-8">
            <div class="card-body text-left">
                <h5 class="card-title">PT. BUMIMULIA INDAH LESTARI</h5>
                <p class="card-text small">was founded in 1997 with its first plant located in Cikarang,
                    West Java, Indonesia. We started with Extrusion Blow Moulding and Injection Moulding
                    technology.</p>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
            </div>
        </div>
    </div>
</div>
</center>
<br><br>
<center>
<div class="card mb-3" style="max-width: 840px;">
    <div class="row no-gutters">
        <div class="col-md-4">
            <img src="assets/images/person_1.jpg" class="card-img" alt="...">
        </div>
        <div class="col-md-8">
            <div class="card-body text-left">
                <h5 class="card-title">PT. BUMIMULIA INDAH LESTARI</h5>
                <p class="card-text small">was founded in 1997 with its first plant located in Cikarang,
                    West Java, Indonesia. We started with Extrusion Blow Moulding and Injection Moulding
                    technology.</p>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
            </div>
        </div>
    </div>
</div>
</center>
<br><br>
<center>
<div class="card mb-3" style="max-width: 840px;">
    <div class="row no-gutters">
        <div class="col-md-4">
            <img src="assets/images/person_1.jpg" class="card-img" alt="...">
        </div>
        <div class="col-md-8">
            <div class="card-body text-left">
                <h5 class="card-title">PT. BUMIMULIA INDAH LESTARI</h5>
                <p class="card-text small">was founded in 1997 with its first plant located in Cikarang,
                    West Java, Indonesia. We started with Extrusion Blow Moulding and Injection Moulding
                    technology.</p>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
            </div>
        </div>
    </div>
</div>
</center>
<br><br>