<div class="site-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9 mb-4">
                <br><br>
                <h2 class="section-title-underline mb-5">
                    <span><b>Berita PPDB 2020</b></span>
                </h2>
                <p class="mb-5">
                    <img src="assets/images/depan.png" alt="Image" class="img-fluid">
                </p><br>
                <p class="mb-5">
                    <img src="assets/images/ppdb1.jpg" alt="Image" class="img-fluid">
                </p><br>
                <p class="mb-5">
                    <img src="assets/images/ppdb3.jpg" alt="Image" class="img-fluid">
                </p><br>
                <p class="mb-5">
                    <img src="assets/images/ppdb4.jpg" alt="Image" class="img-fluid">
                </p>
            </div>

        </div>
    </div>
</div>