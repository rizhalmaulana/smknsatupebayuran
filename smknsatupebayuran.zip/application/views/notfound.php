<div class="site-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9 mb-4">
                <p class="mb-5">
                    <center><img src="assets/images/vector/error.jpg" style="width: 400px; 400px" alt="Image" class="img-fluid"></center>
                </p>
                <p><center><a href="<?= base_url('home'); ?>" class="btn btn-primary px-4 rounded-0">Kembali</a></center></p>
                <br>
            </div>
        </div>
    </div>
</div>